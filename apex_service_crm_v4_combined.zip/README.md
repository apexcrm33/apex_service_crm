# Apex Service CRM (MVP)

## Prereqs
- PostgreSQL 14+
- CMake 3.20+, g++ (or clang++)
- Drogon framework (`brew install drogon` or `apt install libdrogon-dev`)
- (Optional) OpenSSL dev for hashing (`libssl-dev` on Debian)

## Setup (Backend)
```bash
createdb apex_crm
psql -d apex_crm -f server/migrations/00_roles.sql   -f server/migrations/01_users.sql   -f server/migrations/02_warehouses.sql   -f server/migrations/03_skus.sql   -f server/migrations/04_inventory.sql   -f server/migrations/05_customers_locations_assets.sql   -f server/migrations/06_jobs.sql   -f server/migrations/07_inventory_txn.sql   -f server/migrations/08_invoices_payments.sql

cd server
mkdir -p build && cd build
cmake .. && cmake --build . -j
./server
```

### Quick Test (HTTP)
- `POST /api/signup` {"name":"Tech One","email":"t@x.com","password":"pw","role":"TECH"}
- Create VAN warehouse for the technician id returned:
  `POST /api/warehouses` {"name":"Van-1","type":"VAN","owner_user_id":<techId>}
- Create SKU: `POST /api/skus` {"code":"LM-87504","name":"LiftMaster 87504","price":399.0}
- Add inventory to van: `POST /api/warehouses/{vanId}/inventory/{skuId}` {"qty":5,"reason":"RECEIVE"}
- Create customer, location (via SQL for now or extend controller)
- Create job: `POST /api/jobs` {"location_id":1,"technician_id":<techId>,"scheduled_for":"2025-08-12T10:00:00Z"}
- Add job item: `POST /api/jobs/{jobId}/items` {"sku_id":<skuId>,"description":"Opener","qty":1,"unit_price":399.0,"is_inventory":true}
- Complete job (set header `X-User-Id: <techId>` not required for MVP endpoints):
  `POST /api/jobs/{jobId}/complete` {"technicianId":<techId>}
- Get van inventory to see deduction: `GET /api/warehouses/{vanId}/inventory`
- Create invoice: `POST /api/jobs/{jobId}/invoice` -> returns totals

## Frontend (starter)
The `web/` folder contains a minimal Vite React/TS project scaffold with an inventory table and customers page.
```bash
cd web
npm i
npm run dev
```
(Configure a proxy to `http://localhost:8080` in `vite.config.ts` if desired.)


## Auth (JWT)
- `POST /api/login` returns `{ token }`.
- Include `Authorization: Bearer <token>` on protected endpoints.
- Configure `jwt_secret` in `server/config.json`.

## Stripe (test mode)
- Set `"stripe_secret": "sk_test_..."` in `server/config.json`.
- Create PaymentIntent: `POST /api/invoices/{id}/pay-intent` -> returns Stripe JSON (client_secret).
- Webhook receiver: `POST /api/stripe/webhook` (marks invoice PAID on `payment_intent.succeeded`).
- For local testing: `stripe listen --forward-to localhost:8080/api/stripe/webhook`.

## Drag & Drop Jobs Board
- Web app uses `@hello-pangea/dnd` to drag jobs between status columns.
