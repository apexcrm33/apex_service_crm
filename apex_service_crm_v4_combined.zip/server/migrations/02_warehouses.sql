CREATE TYPE warehouse_type AS ENUM ('MAIN','VAN');
CREATE TABLE IF NOT EXISTS warehouses (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  type warehouse_type NOT NULL,
  owner_user_id BIGINT REFERENCES users(id)
);
