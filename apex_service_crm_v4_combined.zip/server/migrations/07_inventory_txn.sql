CREATE TYPE inv_reason AS ENUM ('ADJUST','RECEIVE','RESERVE','ISSUE','RETURN','TRANSFER');
CREATE TYPE inv_ref AS ENUM ('JOB','PO','COUNT','MOVE');
CREATE TABLE IF NOT EXISTS inventory_txn (
  id BIGSERIAL PRIMARY KEY,
  ts TIMESTAMPTZ DEFAULT now(),
  warehouse_id BIGINT NOT NULL REFERENCES warehouses(id),
  sku_id BIGINT NOT NULL REFERENCES skus(id),
  qty_delta NUMERIC(12,2) NOT NULL,
  reason inv_reason NOT NULL,
  ref_type inv_ref,
  ref_id BIGINT
);
