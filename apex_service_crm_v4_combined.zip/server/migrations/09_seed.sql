-- Basic seed for quick demo
INSERT INTO users (role,name,phone,email,password_hash) VALUES
('TECH','Tech One','239-000-0001','tech1@example.com','e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855') ON CONFLICT DO NOTHING;

-- Create a VAN for Tech One (id may vary; assume 1)
INSERT INTO warehouses (name, type, owner_user_id) VALUES ('Van-1','VAN',1);

-- SKUs
INSERT INTO skus (name, code, description, unit, cost, price) VALUES
('LiftMaster 87504','LM-87504','Belt drive opener','each',250,399),
('Torsion Spring .250x2"','SP-250-2','Standard torsion spring','each',30,89)
ON CONFLICT DO NOTHING;

-- Customers & locations
INSERT INTO customers (name,phone,email) VALUES ('John Doe','239-111-2222','john@example.com');
INSERT INTO locations (customer_id,address1,city,state,zip,notes) VALUES (1,'5565 Lee St','Lehigh Acres','FL','33971','Front garage');

-- Inventory receive into van
INSERT INTO inventory (warehouse_id, sku_id, qty_on_hand) VALUES (1,1,5) ON CONFLICT (warehouse_id,sku_id) DO UPDATE SET qty_on_hand=EXCLUDED.qty_on_hand;
