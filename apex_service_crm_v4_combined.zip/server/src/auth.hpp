#pragma once
#include <drogon/drogon.h>
#include <drogon/HttpFilter.h>
#include "jwt.hpp"

class RequireAuth : public drogon::HttpFilter<RequireAuth> {
public:
  void doFilter(const drogon::HttpRequestPtr& req, drogon::FilterCallback&& fcb, drogon::FilterChainCallback&& fccb) override {
    auto auth = req->getHeader("Authorization");
    if(auth.rfind("Bearer ",0)!=0){
      auto res = drogon::HttpResponse::newHttpResponse();
      res->setStatusCode(drogon::k401Unauthorized);
      res->setBody("Missing Bearer token");
      fcb(res); return;
    }
    std::string token = auth.substr(7);
    std::string secret = drogon::app().getCustomConfig()["jwt_secret"].asString();
    nlohmann::json payload;
    if(!jwt_verify_hs256(token, secret, &payload)){
      auto res = drogon::HttpResponse::newHttpResponse();
      res->setStatusCode(drogon::k401Unauthorized);
      res->setBody("Invalid token");
      fcb(res); return;
    }
    req->getAttributes()->insert("user_id", (long)payload.value("sub", 0));
    fccb();
  }
};
