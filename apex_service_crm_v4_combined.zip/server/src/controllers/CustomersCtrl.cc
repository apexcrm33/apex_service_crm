#include "CustomersCtrl.h"
#include "../db.hpp"
#include <json/json.h>
using namespace drogon; using namespace drogon::orm;
void CustomersCtrl::list(const HttpRequestPtr&, std::function<void(const HttpResponsePtr &)> &&cb) const {
  db()->execSqlAsync("SELECT id,name,phone,email FROM customers ORDER BY id DESC",
    [cb](const Result &r){
      Json::Value arr(Json::arrayValue);
      for(auto row: r){
        Json::Value o; o["id"]=(Json::Int64)row["id"].as<long>(); o["name"]=row["name"].as<std::string>();
        o["phone"]=row["phone"].as<std::string>(); o["email"]=row["email"].as<std::string>(); arr.append(o);
      }
      cb(HttpResponse::newHttpJsonResponse(arr));
    },
    [cb](const std::exception &e){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k500InternalServerError); res->setBody(e.what()); cb(res);} );
}
void CustomersCtrl::create(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  auto r = drogon::sync_wait(db()->execSqlCoro("INSERT INTO customers (name,phone,email) VALUES ($1,$2,$3) RETURNING id",
    body["name"].asString(), body.get("phone","").asString(), body.get("email","").asString()));
  Json::Value o; o["id"]=(Json::Int64)r[0]["id"].as<long>(); cb(HttpResponse::newHttpJsonResponse(o));
}
void CustomersCtrl::get(const HttpRequestPtr&, std::function<void(const HttpResponsePtr &)> &&cb, long id) const {
  db()->execSqlAsync("SELECT id,name,phone,email FROM customers WHERE id=$1",
    [cb](const Result &r){
      if(r.size()==0){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k404NotFound); res->setBody("Not found"); cb(res); return; }
      Json::Value o; o["id"]=(Json::Int64)r[0]["id"].as<long>(); o["name"]=r[0]["name"].as<std::string>();
      o["phone"]=r[0]["phone"].as<std::string>(); o["email"]=r[0]["email"].as<std::string>();
      cb(HttpResponse::newHttpJsonResponse(o));
    },
    [cb](const std::exception &e){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k500InternalServerError); res->setBody(e.what()); cb(res);} , id);
}
