#pragma once
#include <drogon/HttpController.h>
class CustomersCtrl : public drogon::HttpController<CustomersCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(CustomersCtrl::list, "/api/customers", drogon::Get, "RequireAuth");
    ADD_METHOD_TO(CustomersCtrl::create, "/api/customers", drogon::Post, "RequireAuth");
    ADD_METHOD_TO(CustomersCtrl::get, "/api/customers/{1}", drogon::Get, "RequireAuth");
  METHOD_LIST_END

  void list(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&) const;
  void create(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&) const;
  void get(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&, long id) const;
};