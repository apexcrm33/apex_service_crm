#include "InventoryCtrl.h"
#include "../services/InventoryService.h"
#include "../db.hpp"
#include <json/json.h>
using namespace drogon; using namespace drogon::orm;

void InventoryCtrl::getByWarehouse(const HttpRequestPtr&, std::function<void(const HttpResponsePtr &)> &&cb, long warehouseId) const {
  db()->execSqlAsync("SELECT i.sku_id, s.code, s.name, i.qty_on_hand FROM inventory i JOIN skus s ON s.id=i.sku_id WHERE i.warehouse_id=$1 ORDER BY s.code",
    [cb](const Result &r){
      Json::Value arr(Json::arrayValue);
      for(auto row: r){ Json::Value o; o["sku_id"]=(Json::Int64)row["sku_id"].as<long>(); o["code"]=row["code"].as<std::string>(); o["name"]=row["name"].as<std::string>(); o["qty"]=row["qty_on_hand"].as<double>(); arr.append(o); }
      cb(HttpResponse::newHttpJsonResponse(arr));
    },
    [cb](const std::exception &e){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k500InternalServerError); res->setBody(e.what()); cb(res);} , warehouseId);
}

void InventoryCtrl::adjust(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb, long warehouseId, long skuId) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  double qty = body["qty"].asDouble(); std::string reason = body.get("reason","ADJUST").asString();
  drogon::sync_wait(InventoryService::adjust(warehouseId, skuId, qty, reason, "COUNT", 0));
  auto res = HttpResponse::newHttpResponse(); res->setStatusCode(k200OK); res->setBody("OK"); cb(res);
}
