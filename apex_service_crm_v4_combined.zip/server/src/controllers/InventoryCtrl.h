#pragma once
#include <drogon/HttpController.h>
class InventoryCtrl : public drogon::HttpController<InventoryCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(InventoryCtrl::getByWarehouse, "/api/warehouses/{1}/inventory", drogon::Get, "RequireAuth");
    ADD_METHOD_TO(InventoryCtrl::adjust, "/api/warehouses/{1}/inventory/{2}", drogon::Post); // {qty, reason}
  METHOD_LIST_END
  void getByWarehouse(const drogon::HttpRequestPtr&, std::function<void (const drogon::HttpResponsePtr &)> &&, long warehouseId) const;
  void adjust(const drogon::HttpRequestPtr&, std::function<void (const drogon::HttpResponsePtr &)> &&, long warehouseId, long skuId) const;
};