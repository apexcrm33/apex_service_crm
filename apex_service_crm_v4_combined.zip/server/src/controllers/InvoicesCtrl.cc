#include "InvoicesCtrl.h"
#include "../db.hpp"
#include <json/json.h>
using namespace drogon; using namespace drogon::orm;
void InvoicesCtrl::createForJob(const HttpRequestPtr&, std::function<void(const HttpResponsePtr &)> &&cb, long jobId) const {
  // naive: sum job_items to invoice
  auto r = drogon::sync_wait(db()->execSqlCoro("SELECT COALESCE(SUM(qty*unit_price),0) FROM job_items WHERE job_id=$1", jobId));
  double subtotal = r[0][0].as<double>();
  double tax = subtotal * 0.0;
  double total = subtotal + tax;
  auto r2 = drogon::sync_wait(db()->execSqlCoro("INSERT INTO invoices (job_id, subtotal, tax, total, status) VALUES ($1,$2,$3,$4,'DRAFT') RETURNING id",
    jobId, subtotal, tax, total));
  Json::Value o; o["invoice_id"]=(Json::Int64)r2[0][0].as<long>(); o["total"]=total;
  cb(HttpResponse::newHttpJsonResponse(o));
}
