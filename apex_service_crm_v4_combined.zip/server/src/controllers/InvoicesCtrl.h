#pragma once
#include <drogon/HttpController.h>
class InvoicesCtrl : public drogon::HttpController<InvoicesCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(InvoicesCtrl::createForJob, "/api/jobs/{1}/invoice", drogon::Post, "RequireAuth");
  METHOD_LIST_END
  void createForJob(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&, long jobId) const;
};