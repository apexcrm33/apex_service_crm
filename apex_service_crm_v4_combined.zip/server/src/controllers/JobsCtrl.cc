#include "JobsCtrl.h"
#include "../services/JobsService.h"
#include "../db.hpp"
#include <json/json.h>
using namespace drogon; using namespace drogon::orm;

void JobsCtrl::list(const HttpRequestPtr&, std::function<void(const HttpResponsePtr &)> &&cb) const {
  db()->execSqlAsync(R"SQL(
    SELECT j.id, j.location_id, j.technician_id, j.scheduled_for, j.status, j.notes,
           c.name AS customer_name, l.address1, l.city, l.state, l.zip
    FROM jobs j
    JOIN locations l ON l.id=j.location_id
    JOIN customers c ON c.id=l.customer_id
    ORDER BY j.scheduled_for NULLS LAST, j.id DESC
  )SQL",
    [cb](const Result &r){
      Json::Value arr(Json::arrayValue);
      for(auto row: r){
        Json::Value o;
        o["id"]=(Json::Int64)row["id"].as<long>();
        o["location_id"]=(Json::Int64)row["location_id"].as<long>();
        o["technician_id"]=(Json::Int64)row["technician_id"].as<long>();
        o["scheduled_for"]=row["scheduled_for"].isNull()? Json::Value(): Json::Value(row["scheduled_for"].as<std::string>());
        o["status"]=row["status"].as<std::string>();
        o["notes"]=row["notes"].as<std::string>();
        o["customer_name"]=row["customer_name"].as<std::string>();
        o["address1"]=row["address1"].as<std::string>();
        o["city"]=row["city"].as<std::string>();
        o["state"]=row["state"].as<std::string>();
        o["zip"]=row["zip"].as<std::string>();
        arr.append(o);
      }
      cb(HttpResponse::newHttpJsonResponse(arr));
    },
    [cb](const std::exception &e){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k500InternalServerError); res->setBody(e.what()); cb(res);} );
}

void JobsCtrl::update(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb, long jobId) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  drogon::sync_wait(db()->execSqlCoro("UPDATE jobs SET technician_id=COALESCE($1,technician_id), scheduled_for=COALESCE($2,scheduled_for), status=COALESCE($3,status), notes=COALESCE($4,notes) WHERE id=$5",
    body.isMember("technician_id")? (long)body["technician_id"].asInt64(): (long)0,
    body.isMember("scheduled_for")? body["scheduled_for"].asString(): "",
    body.isMember("status")? body["status"].asString(): "",
    body.isMember("notes")? body["notes"].asString(): "",
    jobId));
  auto res = HttpResponse::newHttpResponse(); res->setStatusCode(k200OK); res->setBody("Updated"); cb(res);
}

void JobsCtrl::create(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  auto r = drogon::sync_wait(db()->execSqlCoro("INSERT INTO jobs (location_id, technician_id, scheduled_for, status, notes) VALUES ($1,$2,$3,'SCHEDULED',$4) RETURNING id",
    (long)body["location_id"].asInt64(), (long)body.get("technician_id",0).asInt64(), body.get("scheduled_for","").asString(), body.get("notes","").asString()));
  Json::Value o; o["id"]=(Json::Int64)r[0]["id"].as<long>(); cb(HttpResponse::newHttpJsonResponse(o));
}

void JobsCtrl::addItem(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb, long jobId) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  long skuId = body.get("sku_id",0).asInt64();
  std::string desc = body.get("description","").asString();
  double qty = body.get("qty",1.0).asDouble();
  double price = body.get("unit_price",0.0).asDouble();
  bool isInv = body.get("is_inventory",true).asBool();
  drogon::sync_wait(db()->execSqlCoro("INSERT INTO job_items (job_id, sku_id, description, qty, unit_price, is_inventory) VALUES ($1,$2,$3,$4,$5,$6)",
    jobId, skuId, desc, qty, price, isInv));
  auto res = HttpResponse::newHttpResponse(); res->setStatusCode(k200OK); res->setBody("Item added"); cb(res);
}

void JobsCtrl::complete(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb, long jobId) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  long technicianId = body.get("technicianId", 0).asInt64();
  drogon::sync_wait(JobsService::completeJob(jobId, technicianId));
  auto res = HttpResponse::newHttpResponse(); res->setStatusCode(k200OK); res->setBody("Job completed and inventory deducted"); cb(res);
}
