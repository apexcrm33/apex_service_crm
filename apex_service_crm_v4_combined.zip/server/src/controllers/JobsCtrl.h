#pragma once
#include <drogon/HttpController.h>
class JobsCtrl : public drogon::HttpController<JobsCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(JobsCtrl::list, "/api/jobs", drogon::Get, "RequireAuth");
    ADD_METHOD_TO(JobsCtrl::update, "/api/jobs/{1}", drogon::Put, "RequireAuth");
    ADD_METHOD_TO(JobsCtrl::create, "/api/jobs", drogon::Post, "RequireAuth");
    ADD_METHOD_TO(JobsCtrl::addItem, "/api/jobs/{1}/items", drogon::Post, "RequireAuth");
    ADD_METHOD_TO(JobsCtrl::complete, "/api/jobs/{1}/complete", drogon::Post, "RequireAuth");
  METHOD_LIST_END
  void list(const drogon::HttpRequestPtr&, std::function<void (const drogon::HttpResponsePtr &)> &&) const;
  void update(const drogon::HttpRequestPtr&, std::function<void (const drogon::HttpResponsePtr &)> &&, long jobId) const;
  void create(const drogon::HttpRequestPtr&, std::function<void (const drogon::HttpResponsePtr &)> &&) const;
  void addItem(const drogon::HttpRequestPtr&, std::function<void (const drogon::HttpResponsePtr &)> &&, long jobId) const;
  void complete(const drogon::HttpRequestPtr&, std::function<void (const drogon::HttpResponsePtr &)> &&, long jobId) const;
};