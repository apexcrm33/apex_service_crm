#include "LocationsCtrl.h"
#include "../db.hpp"
#include <json/json.h>
using namespace drogon; using namespace drogon::orm;

void LocationsCtrl::listByCustomer(const HttpRequestPtr&, std::function<void(const HttpResponsePtr &)> &&cb, long customerId) const {
  db()->execSqlAsync("SELECT id,address1,city,state,zip,notes FROM locations WHERE customer_id=$1 ORDER BY id DESC",
    [cb](const Result &r){
      Json::Value arr(Json::arrayValue);
      for(auto row: r){
        Json::Value o; o["id"]=(Json::Int64)row["id"].as<long>();
        o["address1"]=row["address1"].as<std::string>(); o["city"]=row["city"].as<std::string>(); o["state"]=row["state"].as<std::string>(); o["zip"]=row["zip"].as<std::string>(); o["notes"]=row["notes"].as<std::string>();
        arr.append(o);
      }
      cb(HttpResponse::newHttpJsonResponse(arr));
    },
    [cb](const std::exception &e){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k500InternalServerError); res->setBody(e.what()); cb(res);} , customerId);
}

void LocationsCtrl::createForCustomer(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb, long customerId) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  auto r = drogon::sync_wait(db()->execSqlCoro("INSERT INTO locations (customer_id,address1,city,state,zip,notes) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id",
    customerId, body["address1"].asString(), body["city"].asString(), body["state"].asString(), body["zip"].asString(), body.get("notes","").asString()));
  Json::Value o; o["id"]=(Json::Int64)r[0]["id"].as<long>(); cb(HttpResponse::newHttpJsonResponse(o));
}
