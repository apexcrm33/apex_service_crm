#pragma once
#include <drogon/HttpController.h>
class LocationsCtrl : public drogon::HttpController<LocationsCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(LocationsCtrl::listByCustomer, "/api/customers/{1}/locations", drogon::Get, "RequireAuth");
    ADD_METHOD_TO(LocationsCtrl::createForCustomer, "/api/customers/{1}/locations", drogon::Post, "RequireAuth");
  METHOD_LIST_END
  void listByCustomer(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&, long customerId) const;
  void createForCustomer(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&, long customerId) const;
};