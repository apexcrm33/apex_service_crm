#include "PaymentsCtrl.h"
#include "../db.hpp"
#include <json/json.h>
#include <string>
using namespace drogon; using namespace drogon::orm;

void PaymentsCtrl::payInvoice(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb, long invoiceId) const {
  // TEST MODE: fake a successful payment, mark invoice PAID and create payments row
  auto r = drogon::sync_wait(db()->execSqlCoro("SELECT total FROM invoices WHERE id=$1", invoiceId));
  if(r.size()==0){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k404NotFound); res->setBody("Invoice not found"); cb(res); return; }
  double total = r[0]["total"].as<double>();
  auto r2 = drogon::sync_wait(db()->execSqlCoro("INSERT INTO payments (invoice_id, amount, method, external_id, status) VALUES ($1,$2,$3,$4,'SUCCEEDED') RETURNING id",
    invoiceId, total, "card_test", "test_"+std::to_string(invoiceId)));
  drogon::sync_wait(db()->execSqlCoro("UPDATE invoices SET status='PAID' WHERE id=$1", invoiceId));
  Json::Value o; o["payment_id"]=(Json::Int64)r2[0]["id"].as<long>(); o["status"]="SUCCEEDED";
  cb(HttpResponse::newHttpJsonResponse(o));
}
