#pragma once
#include <drogon/HttpController.h>
class PaymentsCtrl : public drogon::HttpController<PaymentsCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(PaymentsCtrl::payInvoice, "/api/invoices/{1}/pay", drogon::Post, "RequireAuth");
  METHOD_LIST_END
  void payInvoice(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&, long invoiceId) const;
};