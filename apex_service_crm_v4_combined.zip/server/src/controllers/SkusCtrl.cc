#include "SkusCtrl.h"
#include "../db.hpp"
#include <json/json.h>
using namespace drogon; using namespace drogon::orm;
void SkusCtrl::list(const HttpRequestPtr&, std::function<void(const HttpResponsePtr &)> &&cb) const {
  db()->execSqlAsync("SELECT id,code,name,price FROM skus ORDER BY code",
    [cb](const Result &r){
      Json::Value arr(Json::arrayValue);
      for(auto row: r){ Json::Value o; o["id"]=(Json::Int64)row["id"].as<long>(); o["code"]=row["code"].as<std::string>(); o["name"]=row["name"].as<std::string>(); o["price"]=row["price"].as<double>(); arr.append(o); }
      cb(HttpResponse::newHttpJsonResponse(arr));
    },
    [cb](const std::exception &e){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k500InternalServerError); res->setBody(e.what()); cb(res);} );
}
void SkusCtrl::create(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  auto r = drogon::sync_wait(db()->execSqlCoro("INSERT INTO skus (code,name,price,cost,description) VALUES ($1,$2,$3,$4,$5) RETURNING id",
    body["code"].asString(), body["name"].asString(), body.get("price",0.0).asDouble(), body.get("cost",0.0).asDouble(), body.get("description","").asString()));
  Json::Value o; o["id"]=(Json::Int64)r[0]["id"].as<long>(); cb(HttpResponse::newHttpJsonResponse(o));
}
