#pragma once
#include <drogon/HttpController.h>
class SkusCtrl : public drogon::HttpController<SkusCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(SkusCtrl::list, "/api/skus", drogon::Get, "RequireAuth");
    ADD_METHOD_TO(SkusCtrl::create, "/api/skus", drogon::Post, "RequireAuth");
  METHOD_LIST_END
  void list(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&) const;
  void create(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&) const;
};