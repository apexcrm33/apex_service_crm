#include "StripeCtrl.h"
#include "../db.hpp"
#include <drogon/drogon.h>
#include <json/json.h>

using namespace drogon; using namespace drogon::orm;

void StripeCtrl::createPaymentIntent(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb, long invoiceId) const {
  auto r = drogon::sync_wait(db()->execSqlCoro("SELECT total FROM invoices WHERE id=$1", invoiceId));
  if(r.size()==0){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k404NotFound); res->setBody("Invoice not found"); cb(res); return; }
  double total = r[0]["total"].as<double>();
  int amount = (int)llround(total * 100.0);
  auto client = HttpClient::newHttpClient("https://api.stripe.com");
  auto req2 = HttpRequest::newHttpFormPostRequest("/v1/payment_intents");
  req2->addHeader("Authorization", "Bearer " + drogon::app().getCustomConfig()["stripe_secret"].asString());
  req2->setParameter("amount", std::to_string(amount));
  req2->setParameter("currency", "usd");
  req2->setParameter("metadata[invoice_id]", std::to_string(invoiceId));
  auto [result, resp] = client->sendRequest(req2);
  if(result != ReqResult::Ok || !resp){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k500InternalServerError); res->setBody("Stripe error"); cb(res); return; }
  cb(HttpResponse::newHttpResponse(resp->getBody()));
}

void StripeCtrl::webhook(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb) const {
  // For test mode, skip signature verification; production should verify Stripe-Signature
  Json::CharReaderBuilder b; Json::Value event; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&event,&errs);
  auto type = event.get("type","").asString();
  if(type=="payment_intent.succeeded"){
    auto invId = event["data"]["object"]["metadata"].get("invoice_id","0").asString();
    if(invId!="0"){
      drogon::sync_wait(db()->execSqlCoro("UPDATE invoices SET status='PAID' WHERE id=$1", std::stol(invId)));
    }
  }
  auto res = HttpResponse::newHttpResponse(); res->setStatusCode(k200OK); res->setBody("ok"); cb(res);
}
