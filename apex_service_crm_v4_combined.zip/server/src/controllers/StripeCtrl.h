#pragma once
#include <drogon/HttpController.h>
class StripeCtrl : public drogon::HttpController<StripeCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(StripeCtrl::createPaymentIntent, "/api/invoices/{1}/pay-intent", drogon::Post, "RequireAuth");
    ADD_METHOD_TO(StripeCtrl::webhook, "/api/stripe/webhook", drogon::Post);
  METHOD_LIST_END
  void createPaymentIntent(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&, long invoiceId) const;
  void webhook(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&) const;
};
