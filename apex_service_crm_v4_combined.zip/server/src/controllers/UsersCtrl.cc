#include "UsersCtrl.h"
#include "../db.hpp"
#include "../jwt.hpp"
#include <json/json.h>
#include <openssl/sha.h>
#include <sstream>
#include <iomanip>
#include <chrono>

using namespace drogon; using namespace drogon::orm;

static std::string sha256(const std::string &s){
  unsigned char hash[SHA256_DIGEST_LENGTH];
  SHA256((const unsigned char*)s.data(), s.size(), hash);
  std::ostringstream os; for(int i=0;i<SHA256_DIGEST_LENGTH;i++){ os<<std::hex<<std::setw(2)<<std::setfill('0')<<(int)hash[i]; }
  return os.str();
}

void UsersCtrl::signup(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  auto r = drogon::sync_wait(db()->execSqlCoro("INSERT INTO users (role,name,phone,email,password_hash) VALUES ($1,$2,$3,$4,$5) RETURNING id",
    body.get("role","TECH").asString(), body["name"].asString(), body.get("phone","").asString(), body["email"].asString(), sha256(body["password"].asString())));
  Json::Value o; o["id"]=(Json::Int64)r[0]["id"].as<long>(); cb(HttpResponse::newHttpJsonResponse(o));
}

void UsersCtrl::login(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  auto r = drogon::sync_wait(db()->execSqlCoro("SELECT id,password_hash,role,name FROM users WHERE email=$1", body["email"].asString()));
  if(r.size()==0){ auto res = HttpResponse::newHttpResponse(); res->setStatusCode(k401Unauthorized); res->setBody("Invalid"); cb(res); return; }
  std::string ph = r[0]["password_hash"].as<std::string>();
  if(ph != sha256(body["password"].asString())){ auto res = HttpResponse::newHttpResponse(); res->setStatusCode(k401Unauthorized); res->setBody("Invalid"); cb(res); return; }
  long uid = r[0]["id"].as<long>();
  std::string secret = drogon::app().getCustomConfig()["jwt_secret"].asString();
  auto now = std::chrono::system_clock::now();
  long iat = std::chrono::duration_cast<std::chrono::seconds>(now.time_since_epoch()).count();
  long exp = iat + 60*60*8; // 8 hours
  nlohmann::json payload = { {"sub", uid}, {"iat", iat}, {"exp", exp}, {"role", r[0]["role"].as<std::string>()}, {"name", r[0]["name"].as<std::string>()} };
  std::string token = jwt_sign_hs256(payload, secret);
  Json::Value o; o["token"]=token; o["user_id"]=(Json::Int64)uid;
  cb(HttpResponse::newHttpJsonResponse(o));
}
