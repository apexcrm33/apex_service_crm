#pragma once
#include <drogon/HttpController.h>
class UsersCtrl : public drogon::HttpController<UsersCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(UsersCtrl::signup, "/api/signup", drogon::Post);
    ADD_METHOD_TO(UsersCtrl::login, "/api/login", drogon::Post);
  METHOD_LIST_END
  void signup(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&) const;
  void login(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&) const;
};
