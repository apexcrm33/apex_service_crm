#include "WarehousesCtrl.h"
#include "../db.hpp"
#include <json/json.h>
using namespace drogon; using namespace drogon::orm;
void WarehousesCtrl::list(const HttpRequestPtr&, std::function<void(const HttpResponsePtr &)> &&cb) const {
  db()->execSqlAsync("SELECT id,name,type,owner_user_id FROM warehouses ORDER BY id DESC",
    [cb](const Result &r){
      Json::Value arr(Json::arrayValue);
      for(auto row: r){ Json::Value o; o["id"]=(Json::Int64)row["id"].as<long>(); o["name"]=row["name"].as<std::string>(); o["type"]=row["type"].as<std::string>(); o["owner_user_id"]=(Json::Int64)row["owner_user_id"].as<long>(); arr.append(o); }
      cb(HttpResponse::newHttpJsonResponse(arr));
    },
    [cb](const std::exception &e){ auto res=HttpResponse::newHttpResponse(); res->setStatusCode(k500InternalServerError); res->setBody(e.what()); cb(res);} );
}
void WarehousesCtrl::create(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&cb) const {
  Json::CharReaderBuilder b; Json::Value body; std::string errs; std::istringstream s(req->getBody()); Json::parseFromStream(b,s,&body,&errs);
  auto r = drogon::sync_wait(db()->execSqlCoro("INSERT INTO warehouses (name,type,owner_user_id) VALUES ($1,$2,$3) RETURNING id",
    body["name"].asString(), body.get("type","MAIN").asString(), (long)body.get("owner_user_id", Json::Int64(0)).asInt64()));
  Json::Value o; o["id"]=(Json::Int64)r[0]["id"].as<long>(); cb(HttpResponse::newHttpJsonResponse(o));
}
