#pragma once
#include <drogon/HttpController.h>
class WarehousesCtrl : public drogon::HttpController<WarehousesCtrl> {
public:
  METHOD_LIST_BEGIN
    ADD_METHOD_TO(WarehousesCtrl::list, "/api/warehouses", drogon::Get, "RequireAuth");
    ADD_METHOD_TO(WarehousesCtrl::create, "/api/warehouses", drogon::Post, "RequireAuth");
  METHOD_LIST_END
  void list(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&) const;
  void create(const drogon::HttpRequestPtr&, std::function<void(const drogon::HttpResponsePtr &)> &&) const;
};