#pragma once
#include <drogon/drogon.h>
using drogon::orm::DbClient;
using drogon::orm::DbClientPtr;
using drogon::orm::Mapper;
using drogon::orm::Result;
inline DbClientPtr db(){ return drogon::app().getDbClient(); }
