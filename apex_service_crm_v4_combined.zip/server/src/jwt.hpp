#pragma once
#include <string>
#include <vector>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <nlohmann/json.hpp>
#include <drogon/drogon.h>

inline std::string b64url_encode(const std::string &in){
  static const char *b64="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  std::string out; int val=0, valb=-6;
  for(unsigned char c: in){
    val=(val<<8)+c; valb+=8;
    while(valb>=0){ out.push_back(b64[(val>>valb)&0x3F]); valb-=6; }
  }
  if(valb>-6) out.push_back(b64[((val<<8)>>(valb+8))&0x3F]);
  while(out.size()%4) out.push_back('=');
  for(auto &ch: out){ if(ch=='+') ch='-'; else if(ch=='/') ch='_'; }
  while(!out.empty() && out.back()=='=') out.pop_back();
  return out;
}

inline std::string hmac_sha256(const std::string &key, const std::string &msg){
  unsigned int len=EVP_MAX_MD_SIZE; unsigned char out[EVP_MAX_MD_SIZE];
  HMAC(EVP_sha256(), key.data(), key.size(), (const unsigned char*)msg.data(), msg.size(), out, &len);
  return std::string((char*)out, len);
}

inline std::string jwt_sign_hs256(const nlohmann::json &payload, const std::string &secret){
  nlohmann::json header = {{"alg","HS256"},{"typ","JWT"}};
  std::string head=b64url_encode(header.dump());
  std::string pay =b64url_encode(payload.dump());
  std::string signingInput = head + "." + pay;
  std::string sig = b64url_encode(hmac_sha256(secret, signingInput));
  return signingInput + "." + sig;
}

inline bool jwt_verify_hs256(const std::string &token, const std::string &secret, nlohmann::json *outPayload=nullptr){
  auto p1 = token.find('.'); if(p1==std::string::npos) return false;
  auto p2 = token.find('.', p1+1); if(p2==std::string::npos) return false;
  std::string head = token.substr(0,p1);
  std::string pay  = token.substr(p1+1,p2-(p1+1));
  std::string sig  = token.substr(p2+1);
  std::string signingInput = head + "." + pay;
  std::string expected = b64url_encode(hmac_sha256(secret, signingInput));
  if(expected!=sig) return false;
  try{
    std::string pay_b64 = pay;
    // decode b64url
    std::string s = pay_b64;
    for(auto &c: s){ if(c=='-') c='+'; else if(c=='_') c='/'; }
    while(s.size()%4) s.push_back('=');
    std::string out; out.reserve(s.size());
    // simple base64 decode
    static const std::string chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::vector<int> T(256,-1); for(int i=0;i<64;i++) T[chars[i]]=i;
    int val=0, valb=-8;
    for(unsigned char c: s){
      if(T[c]==-1) break;
      val = (val<<6) + T[c]; valb += 6;
      if(valb>=0){ out.push_back(char((val>>valb)&0xFF)); valb-=8; }
    }
    if(outPayload) *outPayload = nlohmann::json::parse(out);
  } catch(...) { return false; }
  return true;
}
