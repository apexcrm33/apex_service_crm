#include "InventoryService.h"
#include "../db.hpp"
using namespace drogon; using namespace drogon::orm;

Task<> InventoryService::adjust(long warehouseId, long skuId, double qty, const std::string &reason, const std::string &refType, long refId) {
  co_await db()->execSqlCoro("INSERT INTO inventory_txn (warehouse_id, sku_id, qty_delta, reason, ref_type, ref_id) VALUES ($1,$2,$3,$4,$5,$6)",
    warehouseId, skuId, qty, reason, refType, refId);
  co_await db()->execSqlCoro(R"SQL(
    INSERT INTO inventory (warehouse_id, sku_id, qty_on_hand)
    VALUES ($1,$2,$3)
    ON CONFLICT(warehouse_id, sku_id)
    DO UPDATE SET qty_on_hand = inventory.qty_on_hand + EXCLUDED.qty_on_hand
  )SQL", warehouseId, skuId, qty);
  co_return;
}

Task<> InventoryService::issueToJob(long warehouseId, long skuId, double qty, long jobId) {
  co_await adjust(warehouseId, skuId, -qty, "ISSUE", "JOB", jobId);
}

Task<> InventoryService::returnFromJob(long warehouseId, long skuId, double qty, long jobId) {
  co_await adjust(warehouseId, skuId, qty, "RETURN", "JOB", jobId);
}
