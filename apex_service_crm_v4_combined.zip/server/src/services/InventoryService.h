#pragma once
#include <drogon/drogon.h>
#include <string>
class InventoryService {
public:
  static drogon::Task<> adjust(long warehouseId, long skuId, double qty, const std::string &reason, const std::string &refType, long refId);
  static drogon::Task<> issueToJob(long warehouseId, long skuId, double qty, long jobId);
  static drogon::Task<> returnFromJob(long warehouseId, long skuId, double qty, long jobId);
};
