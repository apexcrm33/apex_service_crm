#include "JobsService.h"
#include "InventoryService.h"
#include "../db.hpp"
using namespace drogon; using namespace drogon::orm;

Task<> JobsService::completeJob(long jobId, long technicianId) {
  auto r = co_await db()->execSqlCoro(R"SQL(
    SELECT ji.sku_id, ji.qty, w.id as warehouse_id
    FROM job_items ji
    JOIN jobs j ON j.id = ji.job_id
    JOIN warehouses w ON w.owner_user_id = j.technician_id AND w.type='VAN'
    WHERE j.id=$1 AND j.technician_id=$2 AND ji.is_inventory=true
  )SQL", jobId, technicianId);

  for(auto row: r){
    long skuId = row["sku_id"].as<long>();
    double qty = row["qty"].as<double>();
    long wh = row["warehouse_id"].as<long>();
    co_await InventoryService::issueToJob(wh, skuId, qty, jobId);
  }
  co_await db()->execSqlCoro("UPDATE jobs SET status='COMPLETED' WHERE id=$1", jobId);
}
