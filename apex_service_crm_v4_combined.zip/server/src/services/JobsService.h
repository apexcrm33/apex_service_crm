#pragma once
#include <drogon/drogon.h>
class JobsService {
public:
  static drogon::Task<> completeJob(long jobId, long technicianId);
};
