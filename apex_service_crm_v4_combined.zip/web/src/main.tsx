import React from 'react'
import ReactDOM from 'react-dom/client'
import InventoryTable from './modules/InventoryTable'
import CustomersPage from './modules/CustomersPage'
import JobsBoard from './modules/JobsBoard'
import LocationsPage from './modules/LocationsPage'

function App(){
  const [tab, setTab] = React.useState<'inventory'|'customers'|'jobs'|'locations'>('jobs')
  const [warehouseId, setWarehouseId] = React.useState<number>(1)
  return (
    <div style={{fontFamily:'Inter, system-ui, Arial', padding:16}}>
      <h1>Apex Service CRM (MVP)</h1>
      <nav style={{display:'flex', gap:12, marginBottom:16}}>
        <button onClick={()=>setTab('jobs')}>Jobs</button>
        <button onClick={()=>setTab('inventory')}>Inventory</button>
        <button onClick={()=>setTab('customers')}>Customers</button>
        <button onClick={()=>setTab('locations')}>Locations</button>
      </nav>
      {tab==='inventory' && (
        <div>
          <div style={{display:'flex', gap:24, alignItems:'center'}}>
            <label>Warehouse ID:&nbsp;
              <input value={warehouseId} onChange={(e)=>setWarehouseId(parseInt(e.target.value||'1'))} />
            </label>
          </div>
          <InventoryTable warehouseId={warehouseId} />
        </div>
      )}
      {tab==='customers' && <CustomersPage/>}
      {tab==='jobs' && <JobsBoard/>}
      {tab==='locations' && <LocationsPage/>}
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App/>)
