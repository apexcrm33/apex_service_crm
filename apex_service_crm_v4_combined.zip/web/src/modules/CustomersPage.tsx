import React from 'react'

export default function CustomersPage(){
  const [rows, setRows] = React.useState<any[]>([])
  const [name, setName] = React.useState('')
  const [phone, setPhone] = React.useState('')
  const [email, setEmail] = React.useState('')

  const load = ()=> fetch('/api/customers').then(r=>r.json()).then(setRows)
  React.useEffect(()=>{ load() }, [])

  const create = async ()=>{
    await fetch('/api/customers', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({name, phone, email}) })
    setName(''); setPhone(''); setEmail(''); load()
  }

  return (
    <div>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <input placeholder='Name' value={name} onChange={e=>setName(e.target.value)} />
        <input placeholder='Phone' value={phone} onChange={e=>setPhone(e.target.value)} />
        <input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} />
        <button onClick={create}>Add</button>
      </div>
      <table style={{width:'100%', borderCollapse:'collapse'}}>
        <thead><tr><th style={{border:'1px solid #ddd', padding:8}}>ID</th><th style={{border:'1px solid #ddd', padding:8}}>Name</th><th style={{border:'1px solid #ddd', padding:8}}>Phone</th><th style={{border:'1px solid #ddd', padding:8}}>Email</th></tr></thead>
        <tbody>
          {rows.map((r:any)=> (
            <tr key={r.id}>
              <td style={{border:'1px solid #ddd', padding:8}}>{r.id}</td>
              <td style={{border:'1px solid #ddd', padding:8}}>{r.name}</td>
              <td style={{border:'1px solid #ddd', padding:8}}>{r.phone}</td>
              <td style={{border:'1px solid #ddd', padding:8}}>{r.email}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
