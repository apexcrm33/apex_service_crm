import React from 'react'

export default function InventoryTable({warehouseId}:{warehouseId:number}){
  const [rows, setRows] = React.useState<any[]>([])
  React.useEffect(()=>{
    fetch(`/api/warehouses/${warehouseId}/inventory`).then(r=>r.json()).then(setRows).catch(()=>setRows([]))
  }, [warehouseId])
  return (
    <table style={{width:'100%', borderCollapse:'collapse'}}>
      <thead>
        <tr><th style={{border:'1px solid #ddd', padding:8}}>Code</th><th style={{border:'1px solid #ddd', padding:8}}>Name</th><th style={{border:'1px solid #ddd', padding:8}}>Qty</th></tr>
      </thead>
      <tbody>
        {rows.map((r)=> (
          <tr key={r.sku_id}>
            <td style={{border:'1px solid #ddd', padding:8}}>{r.code}</td>
            <td style={{border:'1px solid #ddd', padding:8}}>{r.name}</td>
            <td style={{border:'1px solid #ddd', padding:8, textAlign:'right'}}>{r.qty}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
