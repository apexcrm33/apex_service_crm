import React from 'react'
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd'

type Job = { id:number; status:string; customer_name:string; scheduled_for?:string; address1:string; city:string; state:string; zip:string }

const COLUMNS = ['SCHEDULED','ENROUTE','ONSITE','COMPLETED'] as const
type Col = typeof COLUMNS[number]

export default function JobsBoard(){
  const [rows, setRows] = React.useState<Job[]>([])
  const load = ()=> fetch('/api/jobs').then(r=>r.json()).then(setRows)
  React.useEffect(()=>{ load() }, [])

  const onDragEnd = async (result: DropResult)=>{
    const { destination, source, draggableId } = result
    if(!destination) return
    const from = source.droppableId as Col
    const to = destination.droppableId as Col
    if(from===to) return
    const jobId = parseInt(draggableId)
    await fetch(`/api/jobs/${jobId}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({status: to}) })
    load()
  }

  const colItems = (col:Col)=> rows.filter(j=>j.status===col)

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:16}}>
        {COLUMNS.map(col=> (
          <Droppable droppableId={col} key={col}>
            {(provided)=>(
              <div ref={provided.innerRef} {...provided.droppableProps} style={{border:'1px solid #ddd', borderRadius:8, padding:8, minHeight:300}}>
                <h3 style={{marginTop:0}}>{col}</h3>
                {colItems(col).map((j, idx)=> (
                  <Draggable draggableId={String(j.id)} index={idx} key={j.id}>
                    {(prov)=>(
                      <div ref={prov.innerRef} {...prov.draggableProps} {...prov.dragHandleProps}
                           style={{background:'#fafafa', border:'1px solid #eee', borderRadius:8, padding:8, marginBottom:8, ...prov.draggableProps.style}}>
                        <div><strong>#{j.id}</strong> — {j.customer_name}</div>
                        <div>{j.address1}, {j.city} {j.state} {j.zip}</div>
                        <div style={{fontSize:12, opacity:0.8}}>When: {j.scheduled_for || '—'}</div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        ))}
      </div>
    </DragDropContext>
  )
}
