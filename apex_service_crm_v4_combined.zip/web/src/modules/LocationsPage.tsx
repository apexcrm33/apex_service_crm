import React from 'react'

export default function LocationsPage(){
  const [customerId, setCustomerId] = React.useState<number>(1)
  const [rows, setRows] = React.useState<any[]>([])
  const [address1, setAddress1] = React.useState('')
  const [city, setCity] = React.useState('')
  const [state, setState] = React.useState('FL')
  const [zip, setZip] = React.useState('')
  const [notes, setNotes] = React.useState('')

  const load = ()=> fetch(`/api/customers/${customerId}/locations`).then(r=>r.json()).then(setRows)
  React.useEffect(()=>{ load() }, [customerId])

  const create = async ()=>{
    await fetch(`/api/customers/${customerId}/locations`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({address1, city, state, zip, notes}) })
    setAddress1(''); setCity(''); setZip(''); setNotes(''); load()
  }

  return (
    <div>
      <div style={{marginBottom:8}}>Customer ID:&nbsp;<input value={customerId} onChange={e=>setCustomerId(parseInt(e.target.value||'1'))} /></div>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <input placeholder='Address' value={address1} onChange={e=>setAddress1(e.target.value)} />
        <input placeholder='City' value={city} onChange={e=>setCity(e.target.value)} />
        <input placeholder='State' value={state} onChange={e=>setState(e.target.value)} />
        <input placeholder='Zip' value={zip} onChange={e=>setZip(e.target.value)} />
        <input placeholder='Notes' value={notes} onChange={e=>setNotes(e.target.value)} />
        <button onClick={create}>Add Location</button>
      </div>
      <table style={{width:'100%', borderCollapse:'collapse'}}>
        <thead><tr><th style={{border:'1px solid #ddd', padding:8}}>ID</th><th style={{border:'1px solid #ddd', padding:8}}>Address</th><th style={{border:'1px solid #ddd', padding:8}}>City</th><th style={{border:'1px solid #ddd', padding:8}}>State</th><th style={{border:'1px solid #ddd', padding:8}}>Zip</th></tr></thead>
        <tbody>
          {rows.map((r:any)=> (
            <tr key={r.id}>
              <td style={{border:'1px solid #ddd', padding:8}}>{r.id}</td>
              <td style={{border:'1px solid #ddd', padding:8}}>{r.address1}</td>
              <td style={{border:'1px solid #ddd', padding:8}}>{r.city}</td>
              <td style={{border:'1px solid #ddd', padding:8}}>{r.state}</td>
              <td style={{border:'1px solid #ddd', padding:8}}>{r.zip}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
